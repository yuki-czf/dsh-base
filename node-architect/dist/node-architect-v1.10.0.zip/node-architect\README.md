# node-architect（节点架构师）—— 集中式多客户端安装包

对抗上下文压缩的长项目开发协议：**文件是记忆，对话不是**。
设计先行 → 节点推进 → 落盘存档（`save.ps1` 管锁与校验）→ 换窗口/压缩后读档无缝续接。

## 最简用法（对任何 agent 说这一句）

> 帮我安装 `<本目录路径>\node-architect` 目录下的 skill

agent 打开本目录读到 `AGENTS.md`，就会在项目根执行 `install.ps1`——无需其他交代。目录放哪都行（解压 zip、U 盘拷贝均可），路径用当时的位置即可。

## 架构：唯一真源 + 客户端联接镜像

```
<项目>\
├── .agents\skills\node-architect\   ← ★ 真源（git 管理；DSH 原生扫描；由母版生成，勿直接改）
├── .opencode\skills\node-architect  ← 联接(junction) → 真源
├── .zcode\skills\node-architect     ← 联接 → 真源
├── .opencode\command\node-architect.md ← opencode 斜杠命令 /node-architect
├── .opencode\command\plan-node.md   ← opencode 斜杠命令 /plan-node（claude 落 .claude\commands\）
├── .pi\prompts\plan-node.md         ← PI-Desktop 斜杠命令 /plan-node（聊天框原生展开）
├── .nodes\                          ← 项目档案（协议真源 PROTOCOL.md + 四件套）
├── AGENTS.md                        ← 内联五条铁律（所有客户端保底入口）
└── .gitignore                       ← 联接镜像为生成物，自动忽略
```

日常维护改**母版** `node-architect\skill\`，重跑 `install.ps1` 同步真源与各端（联接是文件系统层的同一份，真源更新即全端生效）。
真源若被本地改过，覆盖前自动备份到 `.agents\backup\`（重跑不丢改动）。
不支持联接的场景（exFAT/网络盘/故意要提交镜像）加 `-Copy` 用拷贝镜像。
⚠ **改 `skill\scripts\*.ps1` 后必查 UTF-8 BOM 仍在**（文件头 EF BB BF）——部分编辑工具写盘会剥 BOM；无 BOM 时 Windows PowerShell 5.1 按 ANSI 解析，脚本内的中文字符串即碎（v1.6.0 实证踩坑）。修复一行：`[IO.File]::WriteAllText($p,[IO.File]::ReadAllText($p,[Text.Encoding]::UTF8),(New-Object Text.UTF8Encoding($true)))`。

存档的机械动作由 `skill\scripts\save.ps1` 承担：`lock` / `unlock`（CONTEXT 写锁，目录锁原子创建，10 分钟超时）、`verify`（存档完整性校验，归档骨架自动生成）、`verify-batch`（批末收口校验）、`save`（lock→CONTEXT 原子替换→unlock→verify 单命令，常规存档用）、`commit`（同前但收口走 verify-batch，批次场景用）、`trim-decisions`（DECISIONS.md 超 200 行时归档旧段）、`next-node`（新节点原子取号：锁内全表扫描取 max+1 并插行，防并发撞号）、`check-tombstone`（压缩后漏补存档检测）。无 PowerShell 的环境用跨平台版 `skill\scripts\save.mjs`（Node.js，功能对等）。命令速查见 `skill\references\QUICKREF.md`。大节点超上下文预算时拆批执行：先按**询问制**向用户二选一（spec-superflow 重型 / 本分批约定轻量，不混用），选定后在 `.nodes\plans\<节点名>.md` 落批次计划，每批一个全新会话，批末固定走 `commit` 收口（详见 `skill\references\PROTOCOL.md`「批次协议」节）。

**/plan-node 斜杠命令**（v1.10.0）：模板在 `skill\commands\plan-node.md`，install 时自动复制到 opencode（`.opencode\command\`）、claude（`.claude\commands\`）与 PI-Desktop（`.pi\prompts\`，聊天框原生展开，宿主扫描 `<项目>\.pi\prompts\*.md`，支持 `$ARGUMENTS`/`$@`/`$1` 占位）的原生命令目录——「扫描空闲节点号 + 把计划登记为计划节点 + 冲突即停」一条命令完成（等价自然语言「使用存档skill扫描空闲节点并把计划存档为计划节点」）。命令与协议**同包同版本**：dist zip 与云端 remote-install 均随 skill 整体分发，不存在只装其一或版本错配；DSH 等无斜杠命令的端用触发语「登记计划节点 <名>」。

## 一次性引导：让"装节点协议"四个字生效

新项目里的 agent 不知道母版在哪——解法是给每个客户端的全局技能目录装一个 2KB 的**引导技能**（一次性）：

```powershell
powershell -ExecutionPolicy Bypass -File <母版路径>\install.ps1 -Bootstrap          # 四家全局目录全装（opencode/zcode/claude/dsh）
powershell -ExecutionPolicy Bypass -File <母版路径>\install.ps1 -Bootstrap -Clients opencode   # 只装指定家
```

之后**任何新项目、任何客户端**，会话里说一句「装节点协议」→ 引导技能被自动匹配 → 运行母版安装器 → 自动识别客户端 → 装对目录。
换机/移动母版目录后重跑一次 `-Bootstrap`，引导技能里的母版路径自动更新（自愈）。

## 安装到某个项目（一条命令）

```powershell
powershell -ExecutionPolicy Bypass -File <母版路径>\install.ps1                                # 默认装到当前目录
powershell -ExecutionPolicy Bypass -File <母版路径>\install.ps1 -Project D:\www\你的项目 -Clients opencode,zcode   # 跨项目 + 指定客户端
```

自然语言场景：在项目根直接跑脚本（不传 `-Project`），它默认就装到当前项目。

**自动识别**：不传 `-Clients` 时，脚本探测客户端注入的 shell 环境变量指纹（`OPENCODE` → opencode，
`CLAUDECODE` → claude，`ZCODE` → zcode[推测]，`DSH_*` → DSH 免镜像），自动建对应联接。
所以**在客户端会话里让 agent 跑安装，它自己就会装对目录**；裸终端探测不到时只装真源+AGENTS.md 保底层（已够用）。
显式 `-Clients` 与自动探测取并集。

选项：`-Copy` 拷贝镜像｜`-SkipNodes` 不初始化档案｜重复运行安全（幂等，兼作"重建联接"）。

## 大节点拆批执行（分批约定）

节点超出单会话上下文预算时：登记时按**询问制**二选一（spec-superflow 重型 / 本分批约定轻量，不混用）；选本约定则在项目 `.nodes\plans\<节点名>.md` 落批次计划（六列表：批/名称/范围/验收/材料K/前置），一批 = 一个新会话，批末用 `save.ps1 commit` 原子收口（内含 verify-batch 校验）。协议全文见 `.nodes\PROTOCOL.md`「批次协议」节。

## 打包分发 / 换电脑

本目录自包含，整目录拷走即是完整安装源：

```powershell
powershell -ExecutionPolicy Bypass -File <母版路径>\pack.ps1     # 产出 dist\node-architect-v<版本>.zip（附 .sha256）
```

新电脑三步：
1. 解压 zip 到任意固定目录（如 `D:\tools\node-architect`）
2. （可选）跑一次 `install.ps1 -Bootstrap`，让「装节点协议」四个字在新机生效
3. 新项目里对 agent 说「帮我安装 `D:\tools\node-architect` 目录下的 skill」；老项目（随项目目录整体拷贝过来的）在项目根重跑 install 重建联接即可

给别人的电脑：发 zip → 对方解压 → 同上第 2、3 步。仅要求 Windows + PowerShell 5.1（系统自带）。

## 各客户端入口一览

| 客户端 | 入口 | 生效方式 |
|---|---|---|
| 任意（保底） | `AGENTS.md` 内联铁律 | 指令文件，会话自动加载 |
| DSH | `.agents\skills\`（原生扫描，无需镜像） | 技能目录自动发现（已实测） |
| PI-Desktop | `.pi\prompts\plan-node.md` + `.agents\skills\` | 聊天框原生斜杠展开 + 技能目录 |
| opencode | 联接镜像 + `/node-architect` + `/plan-node` 命令 | 技能目录 + 斜杠命令 |
| zcode | 联接镜像（假定 `.zcode\skills`，待实测） | 技能目录 |
| claude code | 联接镜像 `.claude\skills` + `/plan-node` 命令 | 技能目录 + 斜杠命令 |

## 卸载

删除 `.agents\skills\node-architect\`、各客户端镜像联接、`.nodes\`，清理 `AGENTS.md` 与 `.gitignore` 中"节点协议/生成镜像"相关段落。

## 验收

装完在任意客户端打开项目问"当前项目什么状态"——模型应读 `.nodes/CONTEXT.md` 并复述。
